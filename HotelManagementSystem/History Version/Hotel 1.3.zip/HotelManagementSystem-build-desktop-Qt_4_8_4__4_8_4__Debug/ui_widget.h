/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created: Mon Mar 16 19:26:35 2015
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDateEdit>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStackedWidget>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QHBoxLayout *horizontalLayout_8;
    QStackedWidget *stackedWidget;
    QWidget *mainPage;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QTabWidget *mainTabWidget;
    QWidget *CustomOrderM;
    QVBoxLayout *verticalLayout_4;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout_10;
    QGroupBox *customerGroupBox;
    QGridLayout *gridLayout_3;
    QLabel *label;
    QLineEdit *cnameLineEdit;
    QLabel *label_2;
    QRadioButton *cmaleRadioButton;
    QRadioButton *cfemaleRadioButton;
    QLabel *label_3;
    QLineEdit *cidLineEdit;
    QLabel *label_4;
    QLineEdit *cphoneLineEdit;
    QLabel *label_5;
    QDateEdit *ccheckintimeDateEdit;
    QPushButton *newCustomerButton;
    QSpacerItem *verticalSpacer_6;
    QPushButton *commitButton;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *cancelButton;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_9;
    QTableWidget *orderRoomTableWidget;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_11;
    QListWidget *customerListWidget;
    QWidget *RoomInfoM;
    QVBoxLayout *verticalLayout_5;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_10;
    QTableWidget *roomInfoTableWidget;
    QWidget *CheckInM;
    QVBoxLayout *verticalLayout_6;
    QWidget *widget_5;
    QVBoxLayout *verticalLayout_14;
    QHBoxLayout *horizontalLayout_7;
    QGroupBox *customerGroupBox_2;
    QGridLayout *gridLayout_4;
    QLabel *label_6;
    QLineEdit *cnameLineEdit_2;
    QLabel *label_7;
    QRadioButton *cmaleRadioButton_2;
    QRadioButton *cfemaleRadioButton_2;
    QLabel *label_8;
    QLineEdit *cidLineEdit_2;
    QLabel *label_9;
    QLineEdit *cphoneLineEdit_2;
    QLabel *label_10;
    QDateEdit *ccheckintimeDateEdit_2;
    QGroupBox *customerGroupBox_3;
    QGridLayout *gridLayout_5;
    QLabel *label_11;
    QLineEdit *cnameLineEdit_3;
    QLabel *label_12;
    QRadioButton *cmaleRadioButton_3;
    QRadioButton *cfemaleRadioButton_3;
    QLabel *label_13;
    QLineEdit *cidLineEdit_3;
    QLabel *label_14;
    QLineEdit *cphoneLineEdit_3;
    QLabel *label_15;
    QDateEdit *ccheckintimeDateEdit_3;
    QGroupBox *customerGroupBox_4;
    QGridLayout *gridLayout_6;
    QLabel *label_16;
    QLineEdit *cnameLineEdit_4;
    QLabel *label_17;
    QRadioButton *cmaleRadioButton_4;
    QRadioButton *cfemaleRadioButton_4;
    QLabel *label_18;
    QLineEdit *cidLineEdit_4;
    QLabel *label_19;
    QLineEdit *cphoneLineEdit_4;
    QLabel *label_20;
    QDateEdit *ccheckintimeDateEdit_4;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_13;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *commitButton_2;
    QSpacerItem *verticalSpacer_5;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_12;
    QTableWidget *roomTableWidget;
    QWidget *CheckOutM;
    QVBoxLayout *verticalLayout_7;
    QWidget *widget_6;
    QVBoxLayout *verticalLayout_16;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_15;
    QTableWidget *checkInTableWidget;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *moneyAddButton;
    QSpacerItem *horizontalSpacer_7;
    QWidget *EvaluateM;
    QVBoxLayout *verticalLayout_8;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_14;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_12;
    QRadioButton *evluate1RadioButton;
    QRadioButton *evluate2RadioButton;
    QRadioButton *evluate3RadioButton;
    QTextEdit *textEdit;
    QHBoxLayout *horizontalLayout_13;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *submitButton;
    QSpacerItem *horizontalSpacer_9;
    QTableWidget *evluateTableWidget;
    QWidget *loginPage;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer;
    QGridLayout *gridLayout_2;
    QLineEdit *passwordLineEdit;
    QLabel *passwordLabel;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *loginButton;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *exitButton;
    QSpacerItem *horizontalSpacer_5;
    QLabel *usernameLabel;
    QLineEdit *usernameLineEdit;
    QSpacerItem *horizontalSpacer_2;
    QLabel *loginMsgLabel;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(876, 469);
        Widget->setCursor(QCursor(Qt::ArrowCursor));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/res/icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        Widget->setWindowIcon(icon);
        Widget->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout_8 = new QHBoxLayout(Widget);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        stackedWidget = new QStackedWidget(Widget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setLineWidth(0);
        mainPage = new QWidget();
        mainPage->setObjectName(QString::fromUtf8("mainPage"));
        mainPage->setStyleSheet(QString::fromUtf8("#mainPage{border-image:url(:/res/background1.png);}"));
        verticalLayout_3 = new QVBoxLayout(mainPage);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        widget_2 = new QWidget(mainPage);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(9, 9, 9, 9);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        mainTabWidget = new QTabWidget(widget_2);
        mainTabWidget->setObjectName(QString::fromUtf8("mainTabWidget"));
        mainTabWidget->setEnabled(true);
        QFont font;
        font.setPointSize(16);
        mainTabWidget->setFont(font);
        mainTabWidget->setLayoutDirection(Qt::LeftToRight);
        mainTabWidget->setStyleSheet(QString::fromUtf8("background-image: url(:/back);"));
        mainTabWidget->setTabPosition(QTabWidget::North);
        mainTabWidget->setTabShape(QTabWidget::Triangular);
        mainTabWidget->setIconSize(QSize(16, 16));
        mainTabWidget->setElideMode(Qt::ElideNone);
        mainTabWidget->setDocumentMode(false);
        CustomOrderM = new QWidget();
        CustomOrderM->setObjectName(QString::fromUtf8("CustomOrderM"));
        CustomOrderM->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_4 = new QVBoxLayout(CustomOrderM);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        widget_3 = new QWidget(CustomOrderM);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        QFont font1;
        font1.setPointSize(9);
        widget_3->setFont(font1);
        widget_3->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout_5 = new QHBoxLayout(widget_3);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        customerGroupBox = new QGroupBox(widget_3);
        customerGroupBox->setObjectName(QString::fromUtf8("customerGroupBox"));
        gridLayout_3 = new QGridLayout(customerGroupBox);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label = new QLabel(customerGroupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_3->addWidget(label, 0, 0, 1, 1);

        cnameLineEdit = new QLineEdit(customerGroupBox);
        cnameLineEdit->setObjectName(QString::fromUtf8("cnameLineEdit"));
        cnameLineEdit->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));

        gridLayout_3->addWidget(cnameLineEdit, 0, 1, 1, 2);

        label_2 = new QLabel(customerGroupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_3->addWidget(label_2, 1, 0, 1, 1);

        cmaleRadioButton = new QRadioButton(customerGroupBox);
        cmaleRadioButton->setObjectName(QString::fromUtf8("cmaleRadioButton"));
        cmaleRadioButton->setChecked(true);

        gridLayout_3->addWidget(cmaleRadioButton, 1, 1, 1, 1);

        cfemaleRadioButton = new QRadioButton(customerGroupBox);
        cfemaleRadioButton->setObjectName(QString::fromUtf8("cfemaleRadioButton"));

        gridLayout_3->addWidget(cfemaleRadioButton, 1, 2, 1, 1);

        label_3 = new QLabel(customerGroupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_3->addWidget(label_3, 2, 0, 1, 1);

        cidLineEdit = new QLineEdit(customerGroupBox);
        cidLineEdit->setObjectName(QString::fromUtf8("cidLineEdit"));
        cidLineEdit->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        cidLineEdit->setInputMethodHints(Qt::ImhNone);
        cidLineEdit->setMaxLength(18);

        gridLayout_3->addWidget(cidLineEdit, 2, 1, 1, 2);

        label_4 = new QLabel(customerGroupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_3->addWidget(label_4, 3, 0, 1, 1);

        cphoneLineEdit = new QLineEdit(customerGroupBox);
        cphoneLineEdit->setObjectName(QString::fromUtf8("cphoneLineEdit"));
        cphoneLineEdit->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit->setMaxLength(11);

        gridLayout_3->addWidget(cphoneLineEdit, 3, 1, 1, 2);

        label_5 = new QLabel(customerGroupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_3->addWidget(label_5, 4, 0, 1, 1);

        ccheckintimeDateEdit = new QDateEdit(customerGroupBox);
        ccheckintimeDateEdit->setObjectName(QString::fromUtf8("ccheckintimeDateEdit"));
        ccheckintimeDateEdit->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_3->addWidget(ccheckintimeDateEdit, 4, 1, 1, 2);


        verticalLayout_10->addWidget(customerGroupBox);

        newCustomerButton = new QPushButton(widget_3);
        newCustomerButton->setObjectName(QString::fromUtf8("newCustomerButton"));

        verticalLayout_10->addWidget(newCustomerButton);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_6);

        commitButton = new QPushButton(widget_3);
        commitButton->setObjectName(QString::fromUtf8("commitButton"));

        verticalLayout_10->addWidget(commitButton);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        cancelButton = new QPushButton(widget_3);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        horizontalLayout_2->addWidget(cancelButton);


        verticalLayout_10->addLayout(horizontalLayout_2);

        verticalLayout_10->setStretch(0, 3);
        verticalLayout_10->setStretch(5, 1);

        horizontalLayout_5->addLayout(verticalLayout_10);

        groupBox = new QGroupBox(widget_3);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setAlignment(Qt::AlignCenter);
        verticalLayout_9 = new QVBoxLayout(groupBox);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        orderRoomTableWidget = new QTableWidget(groupBox);
        if (orderRoomTableWidget->columnCount() < 3)
            orderRoomTableWidget->setColumnCount(3);
        QFont font2;
        font2.setPointSize(8);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        orderRoomTableWidget->setObjectName(QString::fromUtf8("orderRoomTableWidget"));
        orderRoomTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        orderRoomTableWidget->setAutoScroll(true);
        orderRoomTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        verticalLayout_9->addWidget(orderRoomTableWidget);


        horizontalLayout_5->addWidget(groupBox);

        groupBox_2 = new QGroupBox(widget_3);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setAlignment(Qt::AlignCenter);
        verticalLayout_11 = new QVBoxLayout(groupBox_2);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        customerListWidget = new QListWidget(groupBox_2);
        customerListWidget->setObjectName(QString::fromUtf8("customerListWidget"));
        customerListWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        customerListWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        verticalLayout_11->addWidget(customerListWidget);


        horizontalLayout_5->addWidget(groupBox_2);

        horizontalLayout_5->setStretch(0, 1);
        horizontalLayout_5->setStretch(2, 2);

        verticalLayout_4->addWidget(widget_3);

        mainTabWidget->addTab(CustomOrderM, QString());
        RoomInfoM = new QWidget();
        RoomInfoM->setObjectName(QString::fromUtf8("RoomInfoM"));
        RoomInfoM->setStyleSheet(QString::fromUtf8(""));
        verticalLayout_5 = new QVBoxLayout(RoomInfoM);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        widget_4 = new QWidget(RoomInfoM);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_10 = new QHBoxLayout(widget_4);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        roomInfoTableWidget = new QTableWidget(widget_4);
        if (roomInfoTableWidget->columnCount() < 8)
            roomInfoTableWidget->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(7, __qtablewidgetitem10);
        roomInfoTableWidget->setObjectName(QString::fromUtf8("roomInfoTableWidget"));
        roomInfoTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        roomInfoTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        horizontalLayout_10->addWidget(roomInfoTableWidget);


        verticalLayout_5->addWidget(widget_4);

        mainTabWidget->addTab(RoomInfoM, QString());
        CheckInM = new QWidget();
        CheckInM->setObjectName(QString::fromUtf8("CheckInM"));
        verticalLayout_6 = new QVBoxLayout(CheckInM);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        widget_5 = new QWidget(CheckInM);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        widget_5->setFont(font1);
        verticalLayout_14 = new QVBoxLayout(widget_5);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(11, 11, 11, 11);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setSizeConstraint(QLayout::SetFixedSize);
        customerGroupBox_2 = new QGroupBox(widget_5);
        customerGroupBox_2->setObjectName(QString::fromUtf8("customerGroupBox_2"));
        gridLayout_4 = new QGridLayout(customerGroupBox_2);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        label_6 = new QLabel(customerGroupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_4->addWidget(label_6, 0, 0, 1, 1);

        cnameLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cnameLineEdit_2->setObjectName(QString::fromUtf8("cnameLineEdit_2"));
        cnameLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_4->addWidget(cnameLineEdit_2, 0, 1, 1, 2);

        label_7 = new QLabel(customerGroupBox_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_4->addWidget(label_7, 1, 0, 1, 1);

        cmaleRadioButton_2 = new QRadioButton(customerGroupBox_2);
        cmaleRadioButton_2->setObjectName(QString::fromUtf8("cmaleRadioButton_2"));
        cmaleRadioButton_2->setChecked(true);

        gridLayout_4->addWidget(cmaleRadioButton_2, 1, 1, 1, 1);

        cfemaleRadioButton_2 = new QRadioButton(customerGroupBox_2);
        cfemaleRadioButton_2->setObjectName(QString::fromUtf8("cfemaleRadioButton_2"));

        gridLayout_4->addWidget(cfemaleRadioButton_2, 1, 2, 1, 1);

        label_8 = new QLabel(customerGroupBox_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_4->addWidget(label_8, 2, 0, 1, 1);

        cidLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cidLineEdit_2->setObjectName(QString::fromUtf8("cidLineEdit_2"));
        cidLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_2->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_2->setMaxLength(18);

        gridLayout_4->addWidget(cidLineEdit_2, 2, 1, 1, 2);

        label_9 = new QLabel(customerGroupBox_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_4->addWidget(label_9, 3, 0, 1, 1);

        cphoneLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cphoneLineEdit_2->setObjectName(QString::fromUtf8("cphoneLineEdit_2"));
        cphoneLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_2->setMaxLength(11);

        gridLayout_4->addWidget(cphoneLineEdit_2, 3, 1, 1, 2);

        label_10 = new QLabel(customerGroupBox_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_4->addWidget(label_10, 4, 0, 1, 1);

        ccheckintimeDateEdit_2 = new QDateEdit(customerGroupBox_2);
        ccheckintimeDateEdit_2->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_2"));
        ccheckintimeDateEdit_2->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_4->addWidget(ccheckintimeDateEdit_2, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_2);

        customerGroupBox_3 = new QGroupBox(widget_5);
        customerGroupBox_3->setObjectName(QString::fromUtf8("customerGroupBox_3"));
        gridLayout_5 = new QGridLayout(customerGroupBox_3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_11 = new QLabel(customerGroupBox_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_5->addWidget(label_11, 0, 0, 1, 1);

        cnameLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cnameLineEdit_3->setObjectName(QString::fromUtf8("cnameLineEdit_3"));
        cnameLineEdit_3->setAutoFillBackground(false);
        cnameLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_5->addWidget(cnameLineEdit_3, 0, 1, 1, 2);

        label_12 = new QLabel(customerGroupBox_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_5->addWidget(label_12, 1, 0, 1, 1);

        cmaleRadioButton_3 = new QRadioButton(customerGroupBox_3);
        cmaleRadioButton_3->setObjectName(QString::fromUtf8("cmaleRadioButton_3"));
        cmaleRadioButton_3->setChecked(true);

        gridLayout_5->addWidget(cmaleRadioButton_3, 1, 1, 1, 1);

        cfemaleRadioButton_3 = new QRadioButton(customerGroupBox_3);
        cfemaleRadioButton_3->setObjectName(QString::fromUtf8("cfemaleRadioButton_3"));

        gridLayout_5->addWidget(cfemaleRadioButton_3, 1, 2, 1, 1);

        label_13 = new QLabel(customerGroupBox_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout_5->addWidget(label_13, 2, 0, 1, 1);

        cidLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cidLineEdit_3->setObjectName(QString::fromUtf8("cidLineEdit_3"));
        cidLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_3->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_3->setMaxLength(18);

        gridLayout_5->addWidget(cidLineEdit_3, 2, 1, 1, 2);

        label_14 = new QLabel(customerGroupBox_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_5->addWidget(label_14, 3, 0, 1, 1);

        cphoneLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cphoneLineEdit_3->setObjectName(QString::fromUtf8("cphoneLineEdit_3"));
        cphoneLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_3->setMaxLength(11);

        gridLayout_5->addWidget(cphoneLineEdit_3, 3, 1, 1, 2);

        label_15 = new QLabel(customerGroupBox_3);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout_5->addWidget(label_15, 4, 0, 1, 1);

        ccheckintimeDateEdit_3 = new QDateEdit(customerGroupBox_3);
        ccheckintimeDateEdit_3->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_3"));
        ccheckintimeDateEdit_3->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_5->addWidget(ccheckintimeDateEdit_3, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_3);

        customerGroupBox_4 = new QGroupBox(widget_5);
        customerGroupBox_4->setObjectName(QString::fromUtf8("customerGroupBox_4"));
        gridLayout_6 = new QGridLayout(customerGroupBox_4);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_16 = new QLabel(customerGroupBox_4);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_6->addWidget(label_16, 0, 0, 1, 1);

        cnameLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cnameLineEdit_4->setObjectName(QString::fromUtf8("cnameLineEdit_4"));
        cnameLineEdit_4->setAutoFillBackground(false);
        cnameLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_6->addWidget(cnameLineEdit_4, 0, 1, 1, 2);

        label_17 = new QLabel(customerGroupBox_4);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_6->addWidget(label_17, 1, 0, 1, 1);

        cmaleRadioButton_4 = new QRadioButton(customerGroupBox_4);
        cmaleRadioButton_4->setObjectName(QString::fromUtf8("cmaleRadioButton_4"));
        cmaleRadioButton_4->setChecked(true);

        gridLayout_6->addWidget(cmaleRadioButton_4, 1, 1, 1, 1);

        cfemaleRadioButton_4 = new QRadioButton(customerGroupBox_4);
        cfemaleRadioButton_4->setObjectName(QString::fromUtf8("cfemaleRadioButton_4"));

        gridLayout_6->addWidget(cfemaleRadioButton_4, 1, 2, 1, 1);

        label_18 = new QLabel(customerGroupBox_4);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_6->addWidget(label_18, 2, 0, 1, 1);

        cidLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cidLineEdit_4->setObjectName(QString::fromUtf8("cidLineEdit_4"));
        cidLineEdit_4->setAutoFillBackground(false);
        cidLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_4->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_4->setMaxLength(18);

        gridLayout_6->addWidget(cidLineEdit_4, 2, 1, 1, 2);

        label_19 = new QLabel(customerGroupBox_4);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_6->addWidget(label_19, 3, 0, 1, 1);

        cphoneLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cphoneLineEdit_4->setObjectName(QString::fromUtf8("cphoneLineEdit_4"));
        cphoneLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_4->setMaxLength(11);

        gridLayout_6->addWidget(cphoneLineEdit_4, 3, 1, 1, 2);

        label_20 = new QLabel(customerGroupBox_4);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_6->addWidget(label_20, 4, 0, 1, 1);

        ccheckintimeDateEdit_4 = new QDateEdit(customerGroupBox_4);
        ccheckintimeDateEdit_4->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_4"));
        ccheckintimeDateEdit_4->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_6->addWidget(ccheckintimeDateEdit_4, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_4);


        verticalLayout_14->addLayout(horizontalLayout_7);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        commitButton_2 = new QPushButton(widget_5);
        commitButton_2->setObjectName(QString::fromUtf8("commitButton_2"));

        horizontalLayout_6->addWidget(commitButton_2);


        verticalLayout_13->addLayout(horizontalLayout_6);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_5);


        horizontalLayout_9->addLayout(verticalLayout_13);

        groupBox_3 = new QGroupBox(widget_5);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setAlignment(Qt::AlignCenter);
        verticalLayout_12 = new QVBoxLayout(groupBox_3);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        roomTableWidget = new QTableWidget(groupBox_3);
        if (roomTableWidget->columnCount() < 3)
            roomTableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        __qtablewidgetitem11->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        __qtablewidgetitem12->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        __qtablewidgetitem13->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem13);
        if (roomTableWidget->rowCount() < 1)
            roomTableWidget->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        roomTableWidget->setVerticalHeaderItem(0, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 0, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 1, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 2, __qtablewidgetitem17);
        roomTableWidget->setObjectName(QString::fromUtf8("roomTableWidget"));
        roomTableWidget->setMaximumSize(QSize(599, 16777215));
        roomTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        roomTableWidget->setLineWidth(1);
        roomTableWidget->setAutoScroll(true);
        roomTableWidget->setAutoScrollMargin(16);
        roomTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        roomTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        roomTableWidget->setGridStyle(Qt::DashLine);
        roomTableWidget->setColumnCount(3);
        roomTableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        roomTableWidget->horizontalHeader()->setDefaultSectionSize(101);
        roomTableWidget->horizontalHeader()->setMinimumSectionSize(26);
        roomTableWidget->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        roomTableWidget->verticalHeader()->setDefaultSectionSize(30);
        roomTableWidget->verticalHeader()->setMinimumSectionSize(26);

        verticalLayout_12->addWidget(roomTableWidget);


        horizontalLayout_9->addWidget(groupBox_3);


        verticalLayout_14->addLayout(horizontalLayout_9);


        verticalLayout_6->addWidget(widget_5);

        mainTabWidget->addTab(CheckInM, QString());
        CheckOutM = new QWidget();
        CheckOutM->setObjectName(QString::fromUtf8("CheckOutM"));
        verticalLayout_7 = new QVBoxLayout(CheckOutM);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        widget_6 = new QWidget(CheckOutM);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        widget_6->setFont(font1);
        widget_6->setStyleSheet(QString::fromUtf8("#widget_6{border-image:url(:/new/prefix1/Main);}"));
        verticalLayout_16 = new QVBoxLayout(widget_6);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(11, 11, 11, 11);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        groupBox_4 = new QGroupBox(widget_6);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setAlignment(Qt::AlignCenter);
        verticalLayout_15 = new QVBoxLayout(groupBox_4);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        checkInTableWidget = new QTableWidget(groupBox_4);
        if (checkInTableWidget->columnCount() < 7)
            checkInTableWidget->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem24);
        checkInTableWidget->setObjectName(QString::fromUtf8("checkInTableWidget"));
        checkInTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        checkInTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        checkInTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        checkInTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_15->addWidget(checkInTableWidget);


        verticalLayout_16->addWidget(groupBox_4);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);

        moneyAddButton = new QPushButton(widget_6);
        moneyAddButton->setObjectName(QString::fromUtf8("moneyAddButton"));

        horizontalLayout_11->addWidget(moneyAddButton);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_7);


        verticalLayout_16->addLayout(horizontalLayout_11);


        verticalLayout_7->addWidget(widget_6);

        mainTabWidget->addTab(CheckOutM, QString());
        EvaluateM = new QWidget();
        EvaluateM->setObjectName(QString::fromUtf8("EvaluateM"));
        verticalLayout_8 = new QVBoxLayout(EvaluateM);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        widget_7 = new QWidget(EvaluateM);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        widget_7->setFont(font1);
        horizontalLayout_14 = new QHBoxLayout(widget_7);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        groupBox_5 = new QGroupBox(widget_7);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setAlignment(Qt::AlignCenter);
        verticalLayout_17 = new QVBoxLayout(groupBox_5);
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setContentsMargins(11, 11, 11, 11);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        evluate1RadioButton = new QRadioButton(groupBox_5);
        evluate1RadioButton->setObjectName(QString::fromUtf8("evluate1RadioButton"));
        evluate1RadioButton->setChecked(true);

        horizontalLayout_12->addWidget(evluate1RadioButton);

        evluate2RadioButton = new QRadioButton(groupBox_5);
        evluate2RadioButton->setObjectName(QString::fromUtf8("evluate2RadioButton"));

        horizontalLayout_12->addWidget(evluate2RadioButton);

        evluate3RadioButton = new QRadioButton(groupBox_5);
        evluate3RadioButton->setObjectName(QString::fromUtf8("evluate3RadioButton"));

        horizontalLayout_12->addWidget(evluate3RadioButton);


        verticalLayout_17->addLayout(horizontalLayout_12);

        textEdit = new QTextEdit(groupBox_5);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        verticalLayout_17->addWidget(textEdit);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_8);

        submitButton = new QPushButton(groupBox_5);
        submitButton->setObjectName(QString::fromUtf8("submitButton"));

        horizontalLayout_13->addWidget(submitButton);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_9);


        verticalLayout_17->addLayout(horizontalLayout_13);


        horizontalLayout_14->addWidget(groupBox_5);

        evluateTableWidget = new QTableWidget(widget_7);
        if (evluateTableWidget->columnCount() < 2)
            evluateTableWidget->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        evluateTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        evluateTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem26);
        evluateTableWidget->setObjectName(QString::fromUtf8("evluateTableWidget"));
        evluateTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        evluateTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        evluateTableWidget->setSelectionMode(QAbstractItemView::NoSelection);
        evluateTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        evluateTableWidget->horizontalHeader()->setVisible(false);
        evluateTableWidget->horizontalHeader()->setStretchLastSection(true);

        horizontalLayout_14->addWidget(evluateTableWidget);

        horizontalLayout_14->setStretch(0, 1);
        horizontalLayout_14->setStretch(1, 3);

        verticalLayout_8->addWidget(widget_7);

        mainTabWidget->addTab(EvaluateM, QString());

        horizontalLayout->addWidget(mainTabWidget);


        verticalLayout_3->addWidget(widget_2);

        stackedWidget->addWidget(mainPage);
        loginPage = new QWidget();
        loginPage->setObjectName(QString::fromUtf8("loginPage"));
        loginPage->setStyleSheet(QString::fromUtf8("#widget{border-image:url(:/res/login.jpg);}"));
        verticalLayout_2 = new QVBoxLayout(loginPage);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget = new QWidget(loginPage);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setStyleSheet(QString::fromUtf8(""));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(50, 50, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        passwordLineEdit = new QLineEdit(widget);
        passwordLineEdit->setObjectName(QString::fromUtf8("passwordLineEdit"));
        passwordLineEdit->setMaxLength(15);
        passwordLineEdit->setEchoMode(QLineEdit::Password);

        gridLayout_2->addWidget(passwordLineEdit, 2, 1, 1, 1);

        passwordLabel = new QLabel(widget);
        passwordLabel->setObjectName(QString::fromUtf8("passwordLabel"));
        passwordLabel->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        passwordLabel->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(passwordLabel, 2, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        loginButton = new QPushButton(widget);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));

        horizontalLayout_3->addWidget(loginButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        exitButton = new QPushButton(widget);
        exitButton->setObjectName(QString::fromUtf8("exitButton"));

        horizontalLayout_3->addWidget(exitButton);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);


        gridLayout_2->addLayout(horizontalLayout_3, 3, 0, 1, 2);

        usernameLabel = new QLabel(widget);
        usernameLabel->setObjectName(QString::fromUtf8("usernameLabel"));
        usernameLabel->setAutoFillBackground(false);
        usernameLabel->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        usernameLabel->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(usernameLabel, 1, 0, 1, 1);

        usernameLineEdit = new QLineEdit(widget);
        usernameLineEdit->setObjectName(QString::fromUtf8("usernameLineEdit"));
        usernameLineEdit->setInputMethodHints(Qt::ImhDigitsOnly);
        usernameLineEdit->setMaxLength(20);

        gridLayout_2->addWidget(usernameLineEdit, 1, 1, 1, 1);

        gridLayout_2->setColumnStretch(0, 2);

        horizontalLayout_4->addLayout(gridLayout_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_4);

        loginMsgLabel = new QLabel(widget);
        loginMsgLabel->setObjectName(QString::fromUtf8("loginMsgLabel"));
        loginMsgLabel->setStyleSheet(QString::fromUtf8("color: rgb(222, 0, 0);"));
        loginMsgLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(loginMsgLabel);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);


        verticalLayout_2->addWidget(widget);

        stackedWidget->addWidget(loginPage);

        horizontalLayout_8->addWidget(stackedWidget);


        retranslateUi(Widget);

        stackedWidget->setCurrentIndex(0);
        mainTabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\351\205\222\345\272\227\347\256\241\347\220\206\347\263\273\347\273\237", 0, QApplication::UnicodeUTF8));
        customerGroupBox->setTitle(QApplication::translate("Widget", "\351\242\204\345\256\232\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit->setText(QApplication::translate("Widget", "\350\213\217\347\222\237", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit->setInputMask(QString());
        cidLineEdit->setText(QApplication::translate("Widget", "420116199607264512", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit->setText(QApplication::translate("Widget", "13875241254", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        newCustomerButton->setText(QApplication::translate("Widget", "\345\210\233\345\273\272\346\226\260\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        commitButton->setText(QApplication::translate("Widget", "\346\217\220\344\272\244\351\242\204\345\256\232", 0, QApplication::UnicodeUTF8));
        cancelButton->setText(QApplication::translate("Widget", "\346\222\244\351\224\200\351\242\204\345\256\232", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("Widget", "\345\217\257\344\276\233\351\242\204\345\256\232\347\232\204\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = orderRoomTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Widget", "\345\215\225\344\272\272\351\227\264(\357\277\245240)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = orderRoomTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("Widget", "\345\217\214\344\272\272\351\227\264(\357\277\245220)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = orderRoomTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("Widget", "\344\270\211\344\272\272\351\227\264(\357\277\245270)", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Widget", "\345\267\262\351\242\204\345\256\232\345\256\242\346\210\267\345\220\215\345\215\225", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(CustomOrderM), QApplication::translate("Widget", "\345\256\242\346\210\267\351\242\204\345\256\232\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = roomInfoTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem3->setText(QApplication::translate("Widget", "\346\210\277\351\227\264\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = roomInfoTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem4->setText(QApplication::translate("Widget", "\346\210\277\345\217\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem5 = roomInfoTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem5->setText(QApplication::translate("Widget", "\346\210\277\351\227\264\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem6 = roomInfoTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem6->setText(QApplication::translate("Widget", "\344\273\267\346\240\274", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem7 = roomInfoTableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem7->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem8 = roomInfoTableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem8->setText(QApplication::translate("Widget", "\344\275\217\345\256\2421", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem9 = roomInfoTableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem9->setText(QApplication::translate("Widget", "\344\275\217\345\256\2422", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem10 = roomInfoTableWidget->horizontalHeaderItem(7);
        ___qtablewidgetitem10->setText(QApplication::translate("Widget", "\344\275\217\345\256\2423", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(RoomInfoM), QApplication::translate("Widget", "\346\210\277\345\261\213\344\277\241\346\201\257\346\237\245\350\257\242\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        customerGroupBox_2->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_2->setText(QApplication::translate("Widget", "\346\265\267\346\267\200\345\260\217\351\234\270\347\216\213", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_2->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_2->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_2->setInputMask(QString());
        cidLineEdit_2->setText(QApplication::translate("Widget", "420116199607264512", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_2->setText(QApplication::translate("Widget", "13875241254", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_2->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        customerGroupBox_3->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_3->setText(QString());
        label_12->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_3->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_3->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_3->setInputMask(QString());
        cidLineEdit_3->setText(QString());
        label_14->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_3->setText(QString());
        label_15->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_3->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        customerGroupBox_4->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_4->setText(QString());
        label_17->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_4->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_4->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_18->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_4->setInputMask(QString());
        cidLineEdit_4->setText(QString());
        label_19->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_4->setText(QString());
        label_20->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_4->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        commitButton_2->setText(QApplication::translate("Widget", "\346\217\220\344\272\244", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("Widget", "\345\217\257\344\276\233\345\205\245\344\275\217\347\232\204\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem11 = roomTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem11->setText(QApplication::translate("Widget", "\345\215\225\344\272\272\351\227\264(\357\277\245240)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem12 = roomTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem12->setText(QApplication::translate("Widget", "\345\217\214\344\272\272\351\227\264(\357\277\245220)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem13 = roomTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem13->setText(QApplication::translate("Widget", "\344\270\211\344\272\272\351\227\264(\357\277\245270)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem14 = roomTableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem14->setText(QApplication::translate("Widget", "New Row", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled = roomTableWidget->isSortingEnabled();
        roomTableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem15 = roomTableWidget->item(0, 0);
        ___qtablewidgetitem15->setText(QApplication::translate("Widget", "3", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem16 = roomTableWidget->item(0, 1);
        ___qtablewidgetitem16->setText(QApplication::translate("Widget", "32", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem17 = roomTableWidget->item(0, 2);
        ___qtablewidgetitem17->setText(QApplication::translate("Widget", "32", 0, QApplication::UnicodeUTF8));
        roomTableWidget->setSortingEnabled(__sortingEnabled);

        mainTabWidget->setTabText(mainTabWidget->indexOf(CheckInM), QApplication::translate("Widget", "\345\205\245\344\275\217\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("Widget", "\345\267\262\345\205\245\344\275\217\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem18 = checkInTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem18->setText(QApplication::translate("Widget", "\346\210\277\345\217\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem19 = checkInTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem19->setText(QApplication::translate("Widget", "\346\210\277\345\261\213\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem20 = checkInTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem20->setText(QApplication::translate("Widget", "\346\210\277\344\273\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem21 = checkInTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem21->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem22 = checkInTableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem22->setText(QApplication::translate("Widget", "\344\275\217\345\256\2421", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem23 = checkInTableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem23->setText(QApplication::translate("Widget", "\344\275\217\345\256\2422", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem24 = checkInTableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem24->setText(QApplication::translate("Widget", "\344\275\217\345\256\2423", 0, QApplication::UnicodeUTF8));
        moneyAddButton->setText(QApplication::translate("Widget", "\351\200\200\346\210\277", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(CheckOutM), QApplication::translate("Widget", "\351\200\200\346\210\277\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("Widget", "\350\257\204\344\273\267\346\240\217", 0, QApplication::UnicodeUTF8));
        evluate1RadioButton->setText(QApplication::translate("Widget", "\346\273\241\346\204\217", 0, QApplication::UnicodeUTF8));
        evluate2RadioButton->setText(QApplication::translate("Widget", "\344\270\200\350\210\254", 0, QApplication::UnicodeUTF8));
        evluate3RadioButton->setText(QApplication::translate("Widget", "\344\270\215\346\273\241\346\204\217", 0, QApplication::UnicodeUTF8));
        submitButton->setText(QApplication::translate("Widget", "\346\217\220\344\272\244", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem25 = evluateTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem25->setText(QApplication::translate("Widget", "\346\273\241\346\204\217\347\250\213\345\272\246", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem26 = evluateTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem26->setText(QApplication::translate("Widget", "\351\241\276\345\256\242\350\257\204\344\273\267", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(EvaluateM), QApplication::translate("Widget", "\350\257\204\344\273\267\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        passwordLabel->setText(QApplication::translate("Widget", " \345\257\206  \347\240\201\357\274\232", 0, QApplication::UnicodeUTF8));
        loginButton->setText(QApplication::translate("Widget", "\347\231\273\345\275\225", 0, QApplication::UnicodeUTF8));
        exitButton->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", 0, QApplication::UnicodeUTF8));
        usernameLabel->setText(QApplication::translate("Widget", " \347\224\250\346\210\267\345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        loginMsgLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
