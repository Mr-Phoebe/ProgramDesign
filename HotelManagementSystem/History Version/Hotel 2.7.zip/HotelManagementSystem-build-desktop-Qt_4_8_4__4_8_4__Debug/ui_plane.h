/********************************************************************************
** Form generated from reading UI file 'plane.ui'
**
** Created: Thu Mar 26 19:05:23 2015
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLANE_H
#define UI_PLANE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_plane
{
public:
    QHBoxLayout *horizontalLayout;
    QGridLayout *gridLayout;

    void setupUi(QWidget *plane)
    {
        if (plane->objectName().isEmpty())
            plane->setObjectName(QString::fromUtf8("plane"));
        plane->resize(400, 300);
        horizontalLayout = new QHBoxLayout(plane);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));

        horizontalLayout->addLayout(gridLayout);


        retranslateUi(plane);

        QMetaObject::connectSlotsByName(plane);
    } // setupUi

    void retranslateUi(QWidget *plane)
    {
        plane->setWindowTitle(QApplication::translate("plane", "Form", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class plane: public Ui_plane {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLANE_H
