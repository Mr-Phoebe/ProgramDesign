/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created: Sun May 3 12:23:58 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../HotelManagementSystem/widget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Widget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x08,
      34,    7,    7,    7, 0x08,
      62,    7,    7,    7, 0x08,
      90,    7,    7,    7, 0x08,
     116,    7,    7,    7, 0x08,
     147,    7,    7,    7, 0x08,
     173,    7,    7,    7, 0x08,
     197,    7,    7,    7, 0x08,
     222,    7,    7,    7, 0x08,
     238,    7,    7,    7, 0x08,
     263,  261,    7,    7, 0x08,
     295,    7,    7,    7, 0x08,
     313,    7,    7,    7, 0x08,
     332,    7,    7,    7, 0x08,
     352,    7,    7,    7, 0x08,
     376,    7,    7,    7, 0x08,
     403,  397,    7,    7, 0x08,
     453,    7,    7,    7, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Widget[] = {
    "Widget\0\0on_submitButton_clicked()\0"
    "on_moneyAddButton_clicked()\0"
    "on_commitButton_2_clicked()\0"
    "on_cancelButton_clicked()\0"
    "on_newCustomerButton_clicked()\0"
    "on_commitButton_clicked()\0"
    "on_exitButton_clicked()\0"
    "on_loginButton_clicked()\0updateAllInfo()\0"
    "processOrderCustomer()\0,\0"
    "processCheckInCustomer(int,int)\0"
    "on_Exit_clicked()\0on_About_clicked()\0"
    "on_ExitID_clicked()\0on_Statistics_clicked()\0"
    "on_Display_clicked()\0index\0"
    "on_roomInfoTableWidget_doubleClicked(QModelIndex)\0"
    "on_queryButton_clicked()\0"
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Widget *_t = static_cast<Widget *>(_o);
        switch (_id) {
        case 0: _t->on_submitButton_clicked(); break;
        case 1: _t->on_moneyAddButton_clicked(); break;
        case 2: _t->on_commitButton_2_clicked(); break;
        case 3: _t->on_cancelButton_clicked(); break;
        case 4: _t->on_newCustomerButton_clicked(); break;
        case 5: _t->on_commitButton_clicked(); break;
        case 6: _t->on_exitButton_clicked(); break;
        case 7: _t->on_loginButton_clicked(); break;
        case 8: _t->updateAllInfo(); break;
        case 9: _t->processOrderCustomer(); break;
        case 10: _t->processCheckInCustomer((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->on_Exit_clicked(); break;
        case 12: _t->on_About_clicked(); break;
        case 13: _t->on_ExitID_clicked(); break;
        case 14: _t->on_Statistics_clicked(); break;
        case 15: _t->on_Display_clicked(); break;
        case 16: _t->on_roomInfoTableWidget_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 17: _t->on_queryButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Widget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Widget,
      qt_meta_data_Widget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Widget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Widget))
        return static_cast<void*>(const_cast< Widget*>(this));
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
