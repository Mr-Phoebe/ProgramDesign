#include "widget.h"
#include "ui_widget.h"
#include <QtSql>
#include <QtGui>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    initLoginPage();
//    initMainPage();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::initLoginPage()
{
    ui->stackedWidget->setCurrentIndex(1);
}

/*
// ## 更新其它管理界面所有的信息
void Widget::updateAllInfo()
{
    // ## 更新预定界面的信息
    updateOrderPage();

    // ## 更新入住界面的信息
    updateCheckInPage();

    // ## 更新房屋信息界面
    updateRoomInfoPage();

    // ## 更新退房信息
    updatePayPage();

    // ## 更新评价界面
    updateEvluatePage();
}
*/

void Widget::on_loginButton_clicked()
{
    QString username = ui->usernameLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    // ## 生成查询验证语句
    QString sql = QString("select * from login_t where username = '%1' and password = '%2'").arg(username).arg(password);
    QSqlQuery query(sql);

    if (query.next()) {
        // ## 登录成功转入主界面
        ui->stackedWidget->setCurrentIndex(0);
        // ## 应该是不必要的，因为不会再登录，不过这里也无妨不可
        ui->loginMsgLabel->clear();
    } else {
        // ## 登录失败，显示错误信息
        ui->loginMsgLabel->setText(tr("用户名或密码错误!!!"));
        ui->usernameLineEdit->clear();
        ui->passwordLineEdit->clear();
    }
}

void Widget::on_exitButton_clicked()
{
    close();
}

