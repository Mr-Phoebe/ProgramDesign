/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created: Thu Apr 2 20:51:58 2015
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDateEdit>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStackedWidget>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QHBoxLayout *horizontalLayout_8;
    QStackedWidget *stackedWidget;
    QWidget *mainPage;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_19;
    QTabWidget *mainTabWidget;
    QWidget *CustomOrderM;
    QVBoxLayout *verticalLayout_4;
    QWidget *widget_3;
    QGridLayout *gridLayout_7;
    QVBoxLayout *verticalLayout_10;
    QGroupBox *customerGroupBox;
    QGridLayout *gridLayout_3;
    QDateEdit *ccheckintimeDateEdit;
    QRadioButton *cfemaleRadioButton;
    QRadioButton *cmaleRadioButton;
    QLineEdit *cnameLineEdit;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *cphoneLineEdit;
    QLabel *label_5;
    QLineEdit *cidLineEdit;
    QPushButton *newCustomerButton;
    QSpacerItem *verticalSpacer_6;
    QPushButton *commitButton;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *cancelButton;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_9;
    QTableWidget *orderRoomTableWidget;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_11;
    QListWidget *customerListWidget;
    QWidget *RoomInfoM;
    QVBoxLayout *verticalLayout_5;
    QWidget *widget_4;
    QGridLayout *gridLayout_8;
    QTableWidget *roomInfoTableWidget;
    QWidget *CheckInM;
    QVBoxLayout *verticalLayout_6;
    QWidget *widget_5;
    QGridLayout *gridLayout_9;
    QHBoxLayout *horizontalLayout_7;
    QGroupBox *customerGroupBox_2;
    QGridLayout *gridLayout_4;
    QLabel *label_6;
    QLineEdit *cnameLineEdit_2;
    QLabel *label_7;
    QRadioButton *cmaleRadioButton_2;
    QRadioButton *cfemaleRadioButton_2;
    QLabel *label_8;
    QLineEdit *cidLineEdit_2;
    QLabel *label_9;
    QLineEdit *cphoneLineEdit_2;
    QLabel *label_10;
    QDateEdit *ccheckintimeDateEdit_2;
    QGroupBox *customerGroupBox_3;
    QGridLayout *gridLayout_5;
    QLabel *label_11;
    QLineEdit *cnameLineEdit_3;
    QLabel *label_12;
    QRadioButton *cmaleRadioButton_3;
    QRadioButton *cfemaleRadioButton_3;
    QLabel *label_13;
    QLineEdit *cidLineEdit_3;
    QLabel *label_14;
    QLineEdit *cphoneLineEdit_3;
    QLabel *label_15;
    QDateEdit *ccheckintimeDateEdit_3;
    QGroupBox *customerGroupBox_4;
    QGridLayout *gridLayout_6;
    QLabel *label_16;
    QLineEdit *cnameLineEdit_4;
    QLabel *label_17;
    QRadioButton *cmaleRadioButton_4;
    QRadioButton *cfemaleRadioButton_4;
    QLabel *label_18;
    QLineEdit *cidLineEdit_4;
    QLabel *label_19;
    QLineEdit *cphoneLineEdit_4;
    QLabel *label_20;
    QDateEdit *ccheckintimeDateEdit_4;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_18;
    QVBoxLayout *verticalLayout_13;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *commitButton_2;
    QSpacerItem *verticalSpacer_5;
    QSpacerItem *horizontalSpacer_10;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_12;
    QTableWidget *roomTableWidget;
    QWidget *CheckOutM;
    QVBoxLayout *verticalLayout_7;
    QWidget *widget_6;
    QGridLayout *gridLayout_10;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_15;
    QTableWidget *checkInTableWidget;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *moneyAddButton;
    QSpacerItem *horizontalSpacer_7;
    QWidget *EvaluateM;
    QVBoxLayout *verticalLayout_8;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_14;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_12;
    QRadioButton *evluate1RadioButton;
    QRadioButton *evluate2RadioButton;
    QRadioButton *evluate3RadioButton;
    QTextEdit *textEdit;
    QHBoxLayout *horizontalLayout_13;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *submitButton;
    QSpacerItem *horizontalSpacer_9;
    QTableWidget *evluateTableWidget;
    QWidget *Menu;
    QVBoxLayout *verticalLayout_18;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *horizontalSpacer_15;
    QSpacerItem *horizontalSpacer_16;
    QPushButton *ExitID;
    QPushButton *Exit;
    QPushButton *About;
    QPushButton *Statistics;
    QSpacerItem *horizontalSpacer_14;
    QSpacerItem *horizontalSpacer_11;
    QSpacerItem *horizontalSpacer_13;
    QSpacerItem *horizontalSpacer_17;
    QPushButton *Display;
    QWidget *loginPage;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer;
    QGridLayout *gridLayout_2;
    QLineEdit *passwordLineEdit;
    QLabel *passwordLabel;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *loginButton;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *exitButton;
    QSpacerItem *horizontalSpacer_5;
    QLabel *usernameLabel;
    QLineEdit *usernameLineEdit;
    QSpacerItem *horizontalSpacer_2;
    QLabel *loginMsgLabel;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1026, 500);
        Widget->setCursor(QCursor(Qt::ArrowCursor));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/res/icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        Widget->setWindowIcon(icon);
        Widget->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout_8 = new QHBoxLayout(Widget);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        stackedWidget = new QStackedWidget(Widget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setStyleSheet(QString::fromUtf8(""));
        stackedWidget->setLineWidth(0);
        mainPage = new QWidget();
        mainPage->setObjectName(QString::fromUtf8("mainPage"));
        mainPage->setStyleSheet(QString::fromUtf8("#mainPage{background:url(:/res/background1.png);}"));
        verticalLayout_3 = new QVBoxLayout(mainPage);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        widget_2 = new QWidget(mainPage);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        verticalLayout_19 = new QVBoxLayout(widget_2);
        verticalLayout_19->setSpacing(6);
        verticalLayout_19->setContentsMargins(9, 9, 9, 9);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        mainTabWidget = new QTabWidget(widget_2);
        mainTabWidget->setObjectName(QString::fromUtf8("mainTabWidget"));
        mainTabWidget->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(mainTabWidget->sizePolicy().hasHeightForWidth());
        mainTabWidget->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(16);
        mainTabWidget->setFont(font);
        mainTabWidget->setLayoutDirection(Qt::LeftToRight);
        mainTabWidget->setStyleSheet(QString::fromUtf8("QTabBar::tab:selected\n"
"{\n"
"	border-color: white;\n"
"	color:yellow;\n"
"}\n"
"QTabBar::tab{\n"
"	background: url(:/res/background1.png);\n"
"	color:white;\n"
"	min-width:35ex;\n"
"	min-height:10ex;\n"
"}\n"
"QTabBar::tab:hover\n"
"{\n"
"	background:rgb(255, 255, 255, 100);\n"
"}"));
        mainTabWidget->setTabPosition(QTabWidget::North);
        mainTabWidget->setTabShape(QTabWidget::Triangular);
        mainTabWidget->setIconSize(QSize(16, 16));
        mainTabWidget->setElideMode(Qt::ElideNone);
        mainTabWidget->setDocumentMode(false);
        CustomOrderM = new QWidget();
        CustomOrderM->setObjectName(QString::fromUtf8("CustomOrderM"));
        CustomOrderM->setStyleSheet(QString::fromUtf8("#CustomOrderM{background:url(:/res/background2.png)}"));
        verticalLayout_4 = new QVBoxLayout(CustomOrderM);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        widget_3 = new QWidget(CustomOrderM);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        QFont font1;
        font1.setPointSize(9);
        widget_3->setFont(font1);
        widget_3->setStyleSheet(QString::fromUtf8(""));
        gridLayout_7 = new QGridLayout(widget_3);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        customerGroupBox = new QGroupBox(widget_3);
        customerGroupBox->setObjectName(QString::fromUtf8("customerGroupBox"));
        gridLayout_3 = new QGridLayout(customerGroupBox);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        ccheckintimeDateEdit = new QDateEdit(customerGroupBox);
        ccheckintimeDateEdit->setObjectName(QString::fromUtf8("ccheckintimeDateEdit"));
        ccheckintimeDateEdit->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_3->addWidget(ccheckintimeDateEdit, 4, 1, 1, 2);

        cfemaleRadioButton = new QRadioButton(customerGroupBox);
        cfemaleRadioButton->setObjectName(QString::fromUtf8("cfemaleRadioButton"));

        gridLayout_3->addWidget(cfemaleRadioButton, 1, 2, 1, 1);

        cmaleRadioButton = new QRadioButton(customerGroupBox);
        cmaleRadioButton->setObjectName(QString::fromUtf8("cmaleRadioButton"));
        cmaleRadioButton->setChecked(true);

        gridLayout_3->addWidget(cmaleRadioButton, 1, 1, 1, 1);

        cnameLineEdit = new QLineEdit(customerGroupBox);
        cnameLineEdit->setObjectName(QString::fromUtf8("cnameLineEdit"));
        cnameLineEdit->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));

        gridLayout_3->addWidget(cnameLineEdit, 0, 1, 1, 2);

        label = new QLabel(customerGroupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_3->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(customerGroupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_3->addWidget(label_2, 1, 0, 1, 1);

        label_3 = new QLabel(customerGroupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_3->addWidget(label_3, 2, 0, 1, 1);

        label_4 = new QLabel(customerGroupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_3->addWidget(label_4, 3, 0, 1, 1);

        cphoneLineEdit = new QLineEdit(customerGroupBox);
        cphoneLineEdit->setObjectName(QString::fromUtf8("cphoneLineEdit"));
        cphoneLineEdit->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit->setMaxLength(11);

        gridLayout_3->addWidget(cphoneLineEdit, 3, 1, 1, 2);

        label_5 = new QLabel(customerGroupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_3->addWidget(label_5, 4, 0, 1, 1);

        cidLineEdit = new QLineEdit(customerGroupBox);
        cidLineEdit->setObjectName(QString::fromUtf8("cidLineEdit"));
        cidLineEdit->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        cidLineEdit->setInputMethodHints(Qt::ImhNone);
        cidLineEdit->setMaxLength(18);

        gridLayout_3->addWidget(cidLineEdit, 2, 1, 1, 2);


        verticalLayout_10->addWidget(customerGroupBox);

        newCustomerButton = new QPushButton(widget_3);
        newCustomerButton->setObjectName(QString::fromUtf8("newCustomerButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(newCustomerButton->sizePolicy().hasHeightForWidth());
        newCustomerButton->setSizePolicy(sizePolicy1);
        newCustomerButton->setStyleSheet(QString::fromUtf8("QPushButton#newCustomerButton{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#newCustomerButton:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#newCustomerButton:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        verticalLayout_10->addWidget(newCustomerButton);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_6);

        commitButton = new QPushButton(widget_3);
        commitButton->setObjectName(QString::fromUtf8("commitButton"));
        commitButton->setStyleSheet(QString::fromUtf8("QPushButton#commitButton{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#commitButton:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#commitButton:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        verticalLayout_10->addWidget(commitButton);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        cancelButton = new QPushButton(widget_3);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));
        cancelButton->setStyleSheet(QString::fromUtf8("QPushButton#cancelButton{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#cancelButton:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#cancelButton:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        horizontalLayout_2->addWidget(cancelButton);


        verticalLayout_10->addLayout(horizontalLayout_2);

        verticalLayout_10->setStretch(0, 3);

        gridLayout_7->addLayout(verticalLayout_10, 0, 0, 1, 1);

        groupBox = new QGroupBox(widget_3);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setAlignment(Qt::AlignCenter);
        verticalLayout_9 = new QVBoxLayout(groupBox);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        orderRoomTableWidget = new QTableWidget(groupBox);
        if (orderRoomTableWidget->columnCount() < 4)
            orderRoomTableWidget->setColumnCount(4);
        QFont font2;
        font2.setPointSize(8);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        __qtablewidgetitem1->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        __qtablewidgetitem3->setFont(font2);
        orderRoomTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        orderRoomTableWidget->setObjectName(QString::fromUtf8("orderRoomTableWidget"));
        orderRoomTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        orderRoomTableWidget->setAutoScroll(true);
        orderRoomTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        verticalLayout_9->addWidget(orderRoomTableWidget);


        gridLayout_7->addWidget(groupBox, 0, 1, 1, 1);

        groupBox_2 = new QGroupBox(widget_3);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        sizePolicy.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy);
        groupBox_2->setSizeIncrement(QSize(0, 0));
        groupBox_2->setAlignment(Qt::AlignCenter);
        verticalLayout_11 = new QVBoxLayout(groupBox_2);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        customerListWidget = new QListWidget(groupBox_2);
        customerListWidget->setObjectName(QString::fromUtf8("customerListWidget"));
        customerListWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        customerListWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        customerListWidget->setMovement(QListView::Snap);

        verticalLayout_11->addWidget(customerListWidget);


        gridLayout_7->addWidget(groupBox_2, 0, 2, 1, 1);


        verticalLayout_4->addWidget(widget_3);

        mainTabWidget->addTab(CustomOrderM, QString());
        RoomInfoM = new QWidget();
        RoomInfoM->setObjectName(QString::fromUtf8("RoomInfoM"));
        RoomInfoM->setStyleSheet(QString::fromUtf8("#RoomInfoM{background:url(:/res/background2.png)}"));
        verticalLayout_5 = new QVBoxLayout(RoomInfoM);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        widget_4 = new QWidget(RoomInfoM);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        gridLayout_8 = new QGridLayout(widget_4);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        roomInfoTableWidget = new QTableWidget(widget_4);
        if (roomInfoTableWidget->columnCount() < 8)
            roomInfoTableWidget->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        roomInfoTableWidget->setHorizontalHeaderItem(7, __qtablewidgetitem11);
        roomInfoTableWidget->setObjectName(QString::fromUtf8("roomInfoTableWidget"));
        roomInfoTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        roomInfoTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

        gridLayout_8->addWidget(roomInfoTableWidget, 0, 0, 1, 1);


        verticalLayout_5->addWidget(widget_4);

        mainTabWidget->addTab(RoomInfoM, QString());
        CheckInM = new QWidget();
        CheckInM->setObjectName(QString::fromUtf8("CheckInM"));
        CheckInM->setStyleSheet(QString::fromUtf8("#CheckInM{background:url(:/res/background2.png)}"));
        verticalLayout_6 = new QVBoxLayout(CheckInM);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        widget_5 = new QWidget(CheckInM);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        widget_5->setFont(font1);
        gridLayout_9 = new QGridLayout(widget_5);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setSizeConstraint(QLayout::SetFixedSize);
        customerGroupBox_2 = new QGroupBox(widget_5);
        customerGroupBox_2->setObjectName(QString::fromUtf8("customerGroupBox_2"));
        gridLayout_4 = new QGridLayout(customerGroupBox_2);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        label_6 = new QLabel(customerGroupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_4->addWidget(label_6, 0, 0, 1, 1);

        cnameLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cnameLineEdit_2->setObjectName(QString::fromUtf8("cnameLineEdit_2"));
        cnameLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_4->addWidget(cnameLineEdit_2, 0, 1, 1, 2);

        label_7 = new QLabel(customerGroupBox_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_4->addWidget(label_7, 1, 0, 1, 1);

        cmaleRadioButton_2 = new QRadioButton(customerGroupBox_2);
        cmaleRadioButton_2->setObjectName(QString::fromUtf8("cmaleRadioButton_2"));
        cmaleRadioButton_2->setChecked(true);

        gridLayout_4->addWidget(cmaleRadioButton_2, 1, 1, 1, 1);

        cfemaleRadioButton_2 = new QRadioButton(customerGroupBox_2);
        cfemaleRadioButton_2->setObjectName(QString::fromUtf8("cfemaleRadioButton_2"));

        gridLayout_4->addWidget(cfemaleRadioButton_2, 1, 2, 1, 1);

        label_8 = new QLabel(customerGroupBox_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_4->addWidget(label_8, 2, 0, 1, 1);

        cidLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cidLineEdit_2->setObjectName(QString::fromUtf8("cidLineEdit_2"));
        cidLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_2->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_2->setMaxLength(18);

        gridLayout_4->addWidget(cidLineEdit_2, 2, 1, 1, 2);

        label_9 = new QLabel(customerGroupBox_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_4->addWidget(label_9, 3, 0, 1, 1);

        cphoneLineEdit_2 = new QLineEdit(customerGroupBox_2);
        cphoneLineEdit_2->setObjectName(QString::fromUtf8("cphoneLineEdit_2"));
        cphoneLineEdit_2->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_2->setMaxLength(11);

        gridLayout_4->addWidget(cphoneLineEdit_2, 3, 1, 1, 2);

        label_10 = new QLabel(customerGroupBox_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_4->addWidget(label_10, 4, 0, 1, 1);

        ccheckintimeDateEdit_2 = new QDateEdit(customerGroupBox_2);
        ccheckintimeDateEdit_2->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_2"));
        ccheckintimeDateEdit_2->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_4->addWidget(ccheckintimeDateEdit_2, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_2);

        customerGroupBox_3 = new QGroupBox(widget_5);
        customerGroupBox_3->setObjectName(QString::fromUtf8("customerGroupBox_3"));
        gridLayout_5 = new QGridLayout(customerGroupBox_3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_11 = new QLabel(customerGroupBox_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_5->addWidget(label_11, 0, 0, 1, 1);

        cnameLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cnameLineEdit_3->setObjectName(QString::fromUtf8("cnameLineEdit_3"));
        cnameLineEdit_3->setAutoFillBackground(false);
        cnameLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_5->addWidget(cnameLineEdit_3, 0, 1, 1, 2);

        label_12 = new QLabel(customerGroupBox_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_5->addWidget(label_12, 1, 0, 1, 1);

        cmaleRadioButton_3 = new QRadioButton(customerGroupBox_3);
        cmaleRadioButton_3->setObjectName(QString::fromUtf8("cmaleRadioButton_3"));
        cmaleRadioButton_3->setChecked(true);

        gridLayout_5->addWidget(cmaleRadioButton_3, 1, 1, 1, 1);

        cfemaleRadioButton_3 = new QRadioButton(customerGroupBox_3);
        cfemaleRadioButton_3->setObjectName(QString::fromUtf8("cfemaleRadioButton_3"));

        gridLayout_5->addWidget(cfemaleRadioButton_3, 1, 2, 1, 1);

        label_13 = new QLabel(customerGroupBox_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout_5->addWidget(label_13, 2, 0, 1, 1);

        cidLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cidLineEdit_3->setObjectName(QString::fromUtf8("cidLineEdit_3"));
        cidLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_3->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_3->setMaxLength(18);

        gridLayout_5->addWidget(cidLineEdit_3, 2, 1, 1, 2);

        label_14 = new QLabel(customerGroupBox_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_5->addWidget(label_14, 3, 0, 1, 1);

        cphoneLineEdit_3 = new QLineEdit(customerGroupBox_3);
        cphoneLineEdit_3->setObjectName(QString::fromUtf8("cphoneLineEdit_3"));
        cphoneLineEdit_3->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_3->setMaxLength(11);

        gridLayout_5->addWidget(cphoneLineEdit_3, 3, 1, 1, 2);

        label_15 = new QLabel(customerGroupBox_3);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout_5->addWidget(label_15, 4, 0, 1, 1);

        ccheckintimeDateEdit_3 = new QDateEdit(customerGroupBox_3);
        ccheckintimeDateEdit_3->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_3"));
        ccheckintimeDateEdit_3->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_5->addWidget(ccheckintimeDateEdit_3, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_3);

        customerGroupBox_4 = new QGroupBox(widget_5);
        customerGroupBox_4->setObjectName(QString::fromUtf8("customerGroupBox_4"));
        gridLayout_6 = new QGridLayout(customerGroupBox_4);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_16 = new QLabel(customerGroupBox_4);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_6->addWidget(label_16, 0, 0, 1, 1);

        cnameLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cnameLineEdit_4->setObjectName(QString::fromUtf8("cnameLineEdit_4"));
        cnameLineEdit_4->setAutoFillBackground(false);
        cnameLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));

        gridLayout_6->addWidget(cnameLineEdit_4, 0, 1, 1, 2);

        label_17 = new QLabel(customerGroupBox_4);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_6->addWidget(label_17, 1, 0, 1, 1);

        cmaleRadioButton_4 = new QRadioButton(customerGroupBox_4);
        cmaleRadioButton_4->setObjectName(QString::fromUtf8("cmaleRadioButton_4"));
        cmaleRadioButton_4->setChecked(true);

        gridLayout_6->addWidget(cmaleRadioButton_4, 1, 1, 1, 1);

        cfemaleRadioButton_4 = new QRadioButton(customerGroupBox_4);
        cfemaleRadioButton_4->setObjectName(QString::fromUtf8("cfemaleRadioButton_4"));

        gridLayout_6->addWidget(cfemaleRadioButton_4, 1, 2, 1, 1);

        label_18 = new QLabel(customerGroupBox_4);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_6->addWidget(label_18, 2, 0, 1, 1);

        cidLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cidLineEdit_4->setObjectName(QString::fromUtf8("cidLineEdit_4"));
        cidLineEdit_4->setAutoFillBackground(false);
        cidLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cidLineEdit_4->setInputMethodHints(Qt::ImhNone);
        cidLineEdit_4->setMaxLength(18);

        gridLayout_6->addWidget(cidLineEdit_4, 2, 1, 1, 2);

        label_19 = new QLabel(customerGroupBox_4);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_6->addWidget(label_19, 3, 0, 1, 1);

        cphoneLineEdit_4 = new QLineEdit(customerGroupBox_4);
        cphoneLineEdit_4->setObjectName(QString::fromUtf8("cphoneLineEdit_4"));
        cphoneLineEdit_4->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        cphoneLineEdit_4->setMaxLength(11);

        gridLayout_6->addWidget(cphoneLineEdit_4, 3, 1, 1, 2);

        label_20 = new QLabel(customerGroupBox_4);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_6->addWidget(label_20, 4, 0, 1, 1);

        ccheckintimeDateEdit_4 = new QDateEdit(customerGroupBox_4);
        ccheckintimeDateEdit_4->setObjectName(QString::fromUtf8("ccheckintimeDateEdit_4"));
        ccheckintimeDateEdit_4->setDateTime(QDateTime(QDate(2015, 1, 1), QTime(0, 0, 0)));

        gridLayout_6->addWidget(ccheckintimeDateEdit_4, 4, 1, 1, 2);


        horizontalLayout_7->addWidget(customerGroupBox_4);


        gridLayout_9->addLayout(horizontalLayout_7, 0, 0, 1, 1);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_18);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        commitButton_2 = new QPushButton(widget_5);
        commitButton_2->setObjectName(QString::fromUtf8("commitButton_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(commitButton_2->sizePolicy().hasHeightForWidth());
        commitButton_2->setSizePolicy(sizePolicy2);
        commitButton_2->setStyleSheet(QString::fromUtf8("QPushButton#commitButton_2{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#commitButton_2:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#commitButton_2:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        horizontalLayout_6->addWidget(commitButton_2);


        verticalLayout_13->addLayout(horizontalLayout_6);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_13->addItem(verticalSpacer_5);


        horizontalLayout_9->addLayout(verticalLayout_13);

        horizontalSpacer_10 = new QSpacerItem(89, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_10);

        groupBox_3 = new QGroupBox(widget_5);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        sizePolicy.setHeightForWidth(groupBox_3->sizePolicy().hasHeightForWidth());
        groupBox_3->setSizePolicy(sizePolicy);
        groupBox_3->setAlignment(Qt::AlignCenter);
        verticalLayout_12 = new QVBoxLayout(groupBox_3);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        roomTableWidget = new QTableWidget(groupBox_3);
        if (roomTableWidget->columnCount() < 4)
            roomTableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        __qtablewidgetitem12->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        __qtablewidgetitem13->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        __qtablewidgetitem14->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        __qtablewidgetitem15->setFont(font2);
        roomTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem15);
        if (roomTableWidget->rowCount() < 1)
            roomTableWidget->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        roomTableWidget->setVerticalHeaderItem(0, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 1, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 2, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        roomTableWidget->setItem(0, 3, __qtablewidgetitem20);
        roomTableWidget->setObjectName(QString::fromUtf8("roomTableWidget"));
        roomTableWidget->setMaximumSize(QSize(599, 16777215));
        roomTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        roomTableWidget->setLineWidth(1);
        roomTableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        roomTableWidget->setAutoScroll(true);
        roomTableWidget->setAutoScrollMargin(16);
        roomTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        roomTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        roomTableWidget->setGridStyle(Qt::DashLine);
        roomTableWidget->setColumnCount(4);
        roomTableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        roomTableWidget->horizontalHeader()->setDefaultSectionSize(101);
        roomTableWidget->horizontalHeader()->setMinimumSectionSize(26);
        roomTableWidget->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        roomTableWidget->verticalHeader()->setDefaultSectionSize(30);
        roomTableWidget->verticalHeader()->setMinimumSectionSize(26);

        verticalLayout_12->addWidget(roomTableWidget);


        horizontalLayout_9->addWidget(groupBox_3);


        gridLayout_9->addLayout(horizontalLayout_9, 1, 0, 1, 1);


        verticalLayout_6->addWidget(widget_5);

        mainTabWidget->addTab(CheckInM, QString());
        CheckOutM = new QWidget();
        CheckOutM->setObjectName(QString::fromUtf8("CheckOutM"));
        CheckOutM->setStyleSheet(QString::fromUtf8("#CheckOutM{background:url(:/res/background2.png);}"));
        verticalLayout_7 = new QVBoxLayout(CheckOutM);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        widget_6 = new QWidget(CheckOutM);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        widget_6->setFont(font1);
        widget_6->setStyleSheet(QString::fromUtf8("#widget_6{border-image:url(:/new/prefix1/Main);}"));
        gridLayout_10 = new QGridLayout(widget_6);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        groupBox_4 = new QGroupBox(widget_6);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setAlignment(Qt::AlignCenter);
        verticalLayout_15 = new QVBoxLayout(groupBox_4);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        checkInTableWidget = new QTableWidget(groupBox_4);
        if (checkInTableWidget->columnCount() < 7)
            checkInTableWidget->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        checkInTableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem27);
        checkInTableWidget->setObjectName(QString::fromUtf8("checkInTableWidget"));
        checkInTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        checkInTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        checkInTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        checkInTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_15->addWidget(checkInTableWidget);


        gridLayout_10->addWidget(groupBox_4, 0, 0, 1, 1);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);

        moneyAddButton = new QPushButton(widget_6);
        moneyAddButton->setObjectName(QString::fromUtf8("moneyAddButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(moneyAddButton->sizePolicy().hasHeightForWidth());
        moneyAddButton->setSizePolicy(sizePolicy3);
        moneyAddButton->setStyleSheet(QString::fromUtf8("QPushButton#moneyAddButton{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#moneyAddButton:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#moneyAddButton:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        horizontalLayout_11->addWidget(moneyAddButton);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_7);


        gridLayout_10->addLayout(horizontalLayout_11, 1, 0, 1, 1);


        verticalLayout_7->addWidget(widget_6);

        mainTabWidget->addTab(CheckOutM, QString());
        EvaluateM = new QWidget();
        EvaluateM->setObjectName(QString::fromUtf8("EvaluateM"));
        EvaluateM->setStyleSheet(QString::fromUtf8("#EvaluateM{background:url(:/res/background2.png);}"));
        verticalLayout_8 = new QVBoxLayout(EvaluateM);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        widget_7 = new QWidget(EvaluateM);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        widget_7->setFont(font1);
        horizontalLayout_14 = new QHBoxLayout(widget_7);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        groupBox_5 = new QGroupBox(widget_7);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setAlignment(Qt::AlignCenter);
        verticalLayout_17 = new QVBoxLayout(groupBox_5);
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setContentsMargins(11, 11, 11, 11);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        evluate1RadioButton = new QRadioButton(groupBox_5);
        evluate1RadioButton->setObjectName(QString::fromUtf8("evluate1RadioButton"));
        evluate1RadioButton->setChecked(true);

        horizontalLayout_12->addWidget(evluate1RadioButton);

        evluate2RadioButton = new QRadioButton(groupBox_5);
        evluate2RadioButton->setObjectName(QString::fromUtf8("evluate2RadioButton"));

        horizontalLayout_12->addWidget(evluate2RadioButton);

        evluate3RadioButton = new QRadioButton(groupBox_5);
        evluate3RadioButton->setObjectName(QString::fromUtf8("evluate3RadioButton"));

        horizontalLayout_12->addWidget(evluate3RadioButton);


        verticalLayout_17->addLayout(horizontalLayout_12);

        textEdit = new QTextEdit(groupBox_5);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        verticalLayout_17->addWidget(textEdit);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_8);

        submitButton = new QPushButton(groupBox_5);
        submitButton->setObjectName(QString::fromUtf8("submitButton"));
        sizePolicy3.setHeightForWidth(submitButton->sizePolicy().hasHeightForWidth());
        submitButton->setSizePolicy(sizePolicy3);
        submitButton->setStyleSheet(QString::fromUtf8("QPushButton#submitButton{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#submitButton:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#submitButton:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        horizontalLayout_13->addWidget(submitButton);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_9);


        verticalLayout_17->addLayout(horizontalLayout_13);


        horizontalLayout_14->addWidget(groupBox_5);

        evluateTableWidget = new QTableWidget(widget_7);
        if (evluateTableWidget->columnCount() < 2)
            evluateTableWidget->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        evluateTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        evluateTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem29);
        evluateTableWidget->setObjectName(QString::fromUtf8("evluateTableWidget"));
        evluateTableWidget->setStyleSheet(QString::fromUtf8("background-image:url(:/res/white.png);"));
        evluateTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        evluateTableWidget->setSelectionMode(QAbstractItemView::NoSelection);
        evluateTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        evluateTableWidget->horizontalHeader()->setVisible(false);
        evluateTableWidget->horizontalHeader()->setStretchLastSection(true);

        horizontalLayout_14->addWidget(evluateTableWidget);

        horizontalLayout_14->setStretch(0, 1);
        horizontalLayout_14->setStretch(1, 3);

        verticalLayout_8->addWidget(widget_7);

        mainTabWidget->addTab(EvaluateM, QString());
        Menu = new QWidget();
        Menu->setObjectName(QString::fromUtf8("Menu"));
        Menu->setStyleSheet(QString::fromUtf8("#Menu{background:url(:/res/background2.png);}"));
        verticalLayout_18 = new QVBoxLayout(Menu);
        verticalLayout_18->setSpacing(6);
        verticalLayout_18->setContentsMargins(11, 11, 11, 11);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_12, 11, 1, 1, 1);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_15, 5, 0, 1, 1);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_16, 5, 2, 1, 1);

        ExitID = new QPushButton(Menu);
        ExitID->setObjectName(QString::fromUtf8("ExitID"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(ExitID->sizePolicy().hasHeightForWidth());
        ExitID->setSizePolicy(sizePolicy4);
        QFont font3;
        font3.setFamily(QString::fromUtf8("Adobe Devanagari"));
        font3.setPointSize(16);
        font3.setBold(true);
        font3.setWeight(75);
        ExitID->setFont(font3);
        ExitID->setStyleSheet(QString::fromUtf8("QPushButton#ExitID{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#ExitID:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#ExitID:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        gridLayout->addWidget(ExitID, 8, 1, 1, 1);

        Exit = new QPushButton(Menu);
        Exit->setObjectName(QString::fromUtf8("Exit"));
        sizePolicy4.setHeightForWidth(Exit->sizePolicy().hasHeightForWidth());
        Exit->setSizePolicy(sizePolicy4);
        Exit->setFont(font3);
        Exit->setStyleSheet(QString::fromUtf8("QPushButton#Exit{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#Exit:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#Exit:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        gridLayout->addWidget(Exit, 10, 1, 1, 1);

        About = new QPushButton(Menu);
        About->setObjectName(QString::fromUtf8("About"));
        sizePolicy4.setHeightForWidth(About->sizePolicy().hasHeightForWidth());
        About->setSizePolicy(sizePolicy4);
        QFont font4;
        font4.setFamily(QString::fromUtf8("Adobe Arabic"));
        font4.setPointSize(16);
        font4.setBold(true);
        font4.setWeight(75);
        About->setFont(font4);
        About->setStyleSheet(QString::fromUtf8("QPushButton#About{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#About:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#About:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));
        About->setIconSize(QSize(20, 20));

        gridLayout->addWidget(About, 1, 1, 1, 1);

        Statistics = new QPushButton(Menu);
        Statistics->setObjectName(QString::fromUtf8("Statistics"));
        sizePolicy4.setHeightForWidth(Statistics->sizePolicy().hasHeightForWidth());
        Statistics->setSizePolicy(sizePolicy4);
        Statistics->setFont(font3);
        Statistics->setStyleSheet(QString::fromUtf8("QPushButton#Statistics{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#Statistics:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#Statistics:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        gridLayout->addWidget(Statistics, 5, 1, 1, 1);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_14, 9, 1, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_11, 2, 1, 1, 1);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_13, 7, 1, 1, 1);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_17, 4, 1, 1, 1);

        Display = new QPushButton(Menu);
        Display->setObjectName(QString::fromUtf8("Display"));
        sizePolicy4.setHeightForWidth(Display->sizePolicy().hasHeightForWidth());
        Display->setSizePolicy(sizePolicy4);
        Display->setFont(font4);
        Display->setStyleSheet(QString::fromUtf8("QPushButton#Display{\n"
"background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(214, 214, 214, 255), stop:0.5 rgba(236, 236, 236, 255));\n"
"border: 1px solid rgb(124, 124, 124);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton#Display:hover{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #3C80B1;  \n"
"}\n"
"QPushButton#Display:pressed{\n"
"  background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"  border-radius:5px;\n"
"  border: 1px solid #5F92B2;  \n"
"}"));

        gridLayout->addWidget(Display, 3, 1, 1, 1);


        verticalLayout_18->addLayout(gridLayout);

        mainTabWidget->addTab(Menu, QString());

        verticalLayout_19->addWidget(mainTabWidget);


        verticalLayout_3->addWidget(widget_2);

        stackedWidget->addWidget(mainPage);
        loginPage = new QWidget();
        loginPage->setObjectName(QString::fromUtf8("loginPage"));
        loginPage->setStyleSheet(QString::fromUtf8("#widget{border-image:url(:/res/login.jpg);}"));
        verticalLayout_2 = new QVBoxLayout(loginPage);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget = new QWidget(loginPage);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setStyleSheet(QString::fromUtf8(""));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(50, 50, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        passwordLineEdit = new QLineEdit(widget);
        passwordLineEdit->setObjectName(QString::fromUtf8("passwordLineEdit"));
        passwordLineEdit->setMaxLength(15);
        passwordLineEdit->setEchoMode(QLineEdit::Password);

        gridLayout_2->addWidget(passwordLineEdit, 2, 1, 1, 1);

        passwordLabel = new QLabel(widget);
        passwordLabel->setObjectName(QString::fromUtf8("passwordLabel"));
        passwordLabel->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        passwordLabel->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(passwordLabel, 2, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        loginButton = new QPushButton(widget);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));

        horizontalLayout_3->addWidget(loginButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        exitButton = new QPushButton(widget);
        exitButton->setObjectName(QString::fromUtf8("exitButton"));

        horizontalLayout_3->addWidget(exitButton);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);


        gridLayout_2->addLayout(horizontalLayout_3, 3, 0, 1, 2);

        usernameLabel = new QLabel(widget);
        usernameLabel->setObjectName(QString::fromUtf8("usernameLabel"));
        usernameLabel->setAutoFillBackground(false);
        usernameLabel->setStyleSheet(QString::fromUtf8("border-image:url(:/res/white.png);"));
        usernameLabel->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(usernameLabel, 1, 0, 1, 1);

        usernameLineEdit = new QLineEdit(widget);
        usernameLineEdit->setObjectName(QString::fromUtf8("usernameLineEdit"));
        usernameLineEdit->setInputMethodHints(Qt::ImhDigitsOnly);
        usernameLineEdit->setMaxLength(20);

        gridLayout_2->addWidget(usernameLineEdit, 1, 1, 1, 1);

        gridLayout_2->setColumnStretch(0, 2);

        horizontalLayout_4->addLayout(gridLayout_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_4);

        loginMsgLabel = new QLabel(widget);
        loginMsgLabel->setObjectName(QString::fromUtf8("loginMsgLabel"));
        loginMsgLabel->setStyleSheet(QString::fromUtf8("color: rgb(222, 0, 0);"));
        loginMsgLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(loginMsgLabel);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);


        verticalLayout_2->addWidget(widget);

        stackedWidget->addWidget(loginPage);

        horizontalLayout_8->addWidget(stackedWidget);

        QWidget::setTabOrder(usernameLineEdit, passwordLineEdit);
        QWidget::setTabOrder(passwordLineEdit, loginButton);
        QWidget::setTabOrder(loginButton, exitButton);
        QWidget::setTabOrder(exitButton, cnameLineEdit);
        QWidget::setTabOrder(cnameLineEdit, cmaleRadioButton);
        QWidget::setTabOrder(cmaleRadioButton, cfemaleRadioButton);
        QWidget::setTabOrder(cfemaleRadioButton, cphoneLineEdit);
        QWidget::setTabOrder(cphoneLineEdit, ccheckintimeDateEdit);
        QWidget::setTabOrder(ccheckintimeDateEdit, cidLineEdit);
        QWidget::setTabOrder(cidLineEdit, newCustomerButton);
        QWidget::setTabOrder(newCustomerButton, commitButton);
        QWidget::setTabOrder(commitButton, cancelButton);
        QWidget::setTabOrder(cancelButton, customerListWidget);
        QWidget::setTabOrder(customerListWidget, roomInfoTableWidget);
        QWidget::setTabOrder(roomInfoTableWidget, cnameLineEdit_2);
        QWidget::setTabOrder(cnameLineEdit_2, cmaleRadioButton_2);
        QWidget::setTabOrder(cmaleRadioButton_2, cfemaleRadioButton_2);
        QWidget::setTabOrder(cfemaleRadioButton_2, cidLineEdit_2);
        QWidget::setTabOrder(cidLineEdit_2, cphoneLineEdit_2);
        QWidget::setTabOrder(cphoneLineEdit_2, ccheckintimeDateEdit_2);
        QWidget::setTabOrder(ccheckintimeDateEdit_2, cnameLineEdit_3);
        QWidget::setTabOrder(cnameLineEdit_3, cmaleRadioButton_3);
        QWidget::setTabOrder(cmaleRadioButton_3, cfemaleRadioButton_3);
        QWidget::setTabOrder(cfemaleRadioButton_3, cidLineEdit_3);
        QWidget::setTabOrder(cidLineEdit_3, cphoneLineEdit_3);
        QWidget::setTabOrder(cphoneLineEdit_3, ccheckintimeDateEdit_3);
        QWidget::setTabOrder(ccheckintimeDateEdit_3, cnameLineEdit_4);
        QWidget::setTabOrder(cnameLineEdit_4, cmaleRadioButton_4);
        QWidget::setTabOrder(cmaleRadioButton_4, cfemaleRadioButton_4);
        QWidget::setTabOrder(cfemaleRadioButton_4, cidLineEdit_4);
        QWidget::setTabOrder(cidLineEdit_4, cphoneLineEdit_4);
        QWidget::setTabOrder(cphoneLineEdit_4, ccheckintimeDateEdit_4);
        QWidget::setTabOrder(ccheckintimeDateEdit_4, commitButton_2);
        QWidget::setTabOrder(commitButton_2, roomTableWidget);
        QWidget::setTabOrder(roomTableWidget, evluate1RadioButton);
        QWidget::setTabOrder(evluate1RadioButton, evluate2RadioButton);
        QWidget::setTabOrder(evluate2RadioButton, evluate3RadioButton);
        QWidget::setTabOrder(evluate3RadioButton, textEdit);
        QWidget::setTabOrder(textEdit, submitButton);
        QWidget::setTabOrder(submitButton, evluateTableWidget);
        QWidget::setTabOrder(evluateTableWidget, moneyAddButton);
        QWidget::setTabOrder(moneyAddButton, checkInTableWidget);
        QWidget::setTabOrder(checkInTableWidget, Exit);
        QWidget::setTabOrder(Exit, ExitID);

        retranslateUi(Widget);
        QObject::connect(Exit, SIGNAL(clicked()), mainTabWidget, SLOT(close()));

        stackedWidget->setCurrentIndex(0);
        mainTabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "\351\205\222\345\272\227\347\256\241\347\220\206\347\263\273\347\273\237", 0, QApplication::UnicodeUTF8));
        customerGroupBox->setTitle(QApplication::translate("Widget", "\351\242\204\345\256\232\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cnameLineEdit->setText(QApplication::translate("Widget", "\350\213\217\347\222\237", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit->setText(QApplication::translate("Widget", "13875241254", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit->setInputMask(QString());
        cidLineEdit->setText(QApplication::translate("Widget", "420116199607264512", 0, QApplication::UnicodeUTF8));
        newCustomerButton->setText(QApplication::translate("Widget", "\345\210\233\345\273\272\346\226\260\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        commitButton->setText(QApplication::translate("Widget", "\346\217\220\344\272\244\351\242\204\345\256\232", 0, QApplication::UnicodeUTF8));
        cancelButton->setText(QApplication::translate("Widget", "\346\222\244\351\224\200\351\242\204\345\256\232", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("Widget", "\345\217\257\344\276\233\351\242\204\345\256\232\347\232\204\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = orderRoomTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Widget", "\345\215\225\344\272\272\351\227\264(\357\277\245240)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = orderRoomTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("Widget", "\345\217\214\344\272\272\351\227\264(\357\277\245220)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = orderRoomTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("Widget", "\344\270\211\344\272\272\351\227\264(\357\277\245270)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = orderRoomTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("Widget", "\350\261\252\345\215\216\346\210\277(\357\277\245360)", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Widget", "\345\267\262\351\242\204\345\256\232\345\256\242\346\210\267\345\220\215\345\215\225", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(CustomOrderM), QApplication::translate("Widget", "\345\256\242\346\210\267\351\242\204\345\256\232\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = roomInfoTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem4->setText(QApplication::translate("Widget", "\346\210\277\351\227\264\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem5 = roomInfoTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem5->setText(QApplication::translate("Widget", "\346\210\277\345\217\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem6 = roomInfoTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem6->setText(QApplication::translate("Widget", "\346\210\277\351\227\264\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem7 = roomInfoTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem7->setText(QApplication::translate("Widget", "\344\273\267\346\240\274", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem8 = roomInfoTableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem8->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem9 = roomInfoTableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem9->setText(QApplication::translate("Widget", "\344\275\217\345\256\2421", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem10 = roomInfoTableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem10->setText(QApplication::translate("Widget", "\344\275\217\345\256\2422", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem11 = roomInfoTableWidget->horizontalHeaderItem(7);
        ___qtablewidgetitem11->setText(QApplication::translate("Widget", "\344\275\217\345\256\2423", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(RoomInfoM), QApplication::translate("Widget", "\346\210\277\345\261\213\344\277\241\346\201\257\346\237\245\350\257\242\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        customerGroupBox_2->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_2->setText(QApplication::translate("Widget", "\350\213\217\347\222\237", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_2->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_2->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_2->setInputMask(QString());
        cidLineEdit_2->setText(QApplication::translate("Widget", "420116199607264512", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_2->setText(QApplication::translate("Widget", "13875241254", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_2->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        customerGroupBox_3->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_3->setText(QString());
        label_12->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_3->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_3->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_3->setInputMask(QString());
        cidLineEdit_3->setText(QString());
        label_14->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_3->setText(QString());
        label_15->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_3->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        customerGroupBox_4->setTitle(QApplication::translate("Widget", "\345\205\245\344\275\217\347\224\250\346\210\267\347\232\204\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("Widget", "\345\247\223  \345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        cnameLineEdit_4->setText(QString());
        label_17->setText(QApplication::translate("Widget", "\346\200\247  \345\210\253\357\274\232", 0, QApplication::UnicodeUTF8));
        cmaleRadioButton_4->setText(QApplication::translate("Widget", "\347\224\267", 0, QApplication::UnicodeUTF8));
        cfemaleRadioButton_4->setText(QApplication::translate("Widget", "\345\245\263", 0, QApplication::UnicodeUTF8));
        label_18->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        cidLineEdit_4->setInputMask(QString());
        cidLineEdit_4->setText(QString());
        label_19->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235\357\274\232", 0, QApplication::UnicodeUTF8));
        cphoneLineEdit_4->setText(QString());
        label_20->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264\357\274\232", 0, QApplication::UnicodeUTF8));
        ccheckintimeDateEdit_4->setDisplayFormat(QApplication::translate("Widget", "yyyy-MM-dd", 0, QApplication::UnicodeUTF8));
        commitButton_2->setText(QApplication::translate("Widget", "     \346\217\220\344\272\244     ", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QApplication::translate("Widget", "\345\217\257\344\276\233\345\205\245\344\275\217\347\232\204\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem12 = roomTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem12->setText(QApplication::translate("Widget", "\345\215\225\344\272\272\351\227\264(\357\277\245240)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem13 = roomTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem13->setText(QApplication::translate("Widget", "\345\217\214\344\272\272\351\227\264(\357\277\245220)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem14 = roomTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem14->setText(QApplication::translate("Widget", "\344\270\211\344\272\272\351\227\264(\357\277\245270)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem15 = roomTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem15->setText(QApplication::translate("Widget", "\350\261\252\345\215\216\351\227\264(\357\277\245360)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem16 = roomTableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem16->setText(QApplication::translate("Widget", "New Row", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled = roomTableWidget->isSortingEnabled();
        roomTableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem17 = roomTableWidget->item(0, 0);
        ___qtablewidgetitem17->setText(QApplication::translate("Widget", "3", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem18 = roomTableWidget->item(0, 1);
        ___qtablewidgetitem18->setText(QApplication::translate("Widget", "32", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem19 = roomTableWidget->item(0, 2);
        ___qtablewidgetitem19->setText(QApplication::translate("Widget", "32", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem20 = roomTableWidget->item(0, 3);
        ___qtablewidgetitem20->setText(QApplication::translate("Widget", "21", 0, QApplication::UnicodeUTF8));
        roomTableWidget->setSortingEnabled(__sortingEnabled);

        mainTabWidget->setTabText(mainTabWidget->indexOf(CheckInM), QApplication::translate("Widget", "\345\205\245\344\275\217\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QApplication::translate("Widget", "\345\267\262\345\205\245\344\275\217\344\277\241\346\201\257", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem21 = checkInTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem21->setText(QApplication::translate("Widget", "\346\210\277\345\217\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem22 = checkInTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem22->setText(QApplication::translate("Widget", "\346\210\277\345\261\213\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem23 = checkInTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem23->setText(QApplication::translate("Widget", "\346\210\277\344\273\267", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem24 = checkInTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem24->setText(QApplication::translate("Widget", "\345\205\245\344\275\217\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem25 = checkInTableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem25->setText(QApplication::translate("Widget", "\344\275\217\345\256\2421", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem26 = checkInTableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem26->setText(QApplication::translate("Widget", "\344\275\217\345\256\2422", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem27 = checkInTableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem27->setText(QApplication::translate("Widget", "\344\275\217\345\256\2423", 0, QApplication::UnicodeUTF8));
        moneyAddButton->setText(QApplication::translate("Widget", "\351\200\200\346\210\277", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(CheckOutM), QApplication::translate("Widget", "\351\200\200\346\210\277\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QApplication::translate("Widget", "\350\257\204\344\273\267\346\240\217", 0, QApplication::UnicodeUTF8));
        evluate1RadioButton->setText(QApplication::translate("Widget", "\346\273\241\346\204\217", 0, QApplication::UnicodeUTF8));
        evluate2RadioButton->setText(QApplication::translate("Widget", "\344\270\200\350\210\254", 0, QApplication::UnicodeUTF8));
        evluate3RadioButton->setText(QApplication::translate("Widget", "\344\270\215\346\273\241\346\204\217", 0, QApplication::UnicodeUTF8));
        submitButton->setText(QApplication::translate("Widget", "\346\217\220\344\272\244", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem28 = evluateTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem28->setText(QApplication::translate("Widget", "\346\273\241\346\204\217\347\250\213\345\272\246", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem29 = evluateTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem29->setText(QApplication::translate("Widget", "\351\241\276\345\256\242\350\257\204\344\273\267", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(EvaluateM), QApplication::translate("Widget", "\350\257\204\344\273\267\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        ExitID->setText(QApplication::translate("Widget", "\351\200\200\345\207\272\350\264\246\345\217\267", 0, QApplication::UnicodeUTF8));
        Exit->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", 0, QApplication::UnicodeUTF8));
        About->setText(QApplication::translate("Widget", "\345\205\263\344\272\216", 0, QApplication::UnicodeUTF8));
        Statistics->setText(QApplication::translate("Widget", "\347\273\237\350\256\241", 0, QApplication::UnicodeUTF8));
        Display->setText(QApplication::translate("Widget", "\345\261\225\347\244\272", 0, QApplication::UnicodeUTF8));
        mainTabWidget->setTabText(mainTabWidget->indexOf(Menu), QApplication::translate("Widget", "\351\200\211\351\241\271", 0, QApplication::UnicodeUTF8));
        passwordLabel->setText(QApplication::translate("Widget", " \345\257\206  \347\240\201\357\274\232", 0, QApplication::UnicodeUTF8));
        loginButton->setText(QApplication::translate("Widget", "\347\231\273\345\275\225", 0, QApplication::UnicodeUTF8));
        exitButton->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", 0, QApplication::UnicodeUTF8));
        usernameLabel->setText(QApplication::translate("Widget", " \347\224\250\346\210\267\345\220\215\357\274\232", 0, QApplication::UnicodeUTF8));
        loginMsgLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
